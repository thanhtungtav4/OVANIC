<div class="detail_info seach_taget">
  <smail>Để lại thông tin để được chúng tôi tư vấn trong thời gian nhanh nhất</smail>
  <form  class="form-group w-100" id="product-contact-form" name="form" method="post">
    <input name="fullname" id="fullname" type="text" class="form-control" placeholder="Họ tên" required>
    <input name="numberphone" id="numberphone" type="text" class="form-control" placeholder="Số điện thoại" pattern="(\+84|0){1}(9|8|7|5|3){1}[0-9]{8}" required>
    <input name="product_title" type="hidden" value="<?php the_title(); ?>">
    <input name="action" type="hidden" value="contact_telegram_hook">
    <button class="btn btn-submit" type="submit">Nhận tư vấn</button>
  </form >
  <smail id="nds_form_feedback"></smail>
</div>
